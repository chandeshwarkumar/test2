package com.cognizant.springlearn;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpringLearnApplication {
	
	private static final Logger logger = LoggerFactory.getLogger(SpringLearnApplication.class);

	public static void main(String[] args) {
		logger.info("this is a main class");
		SpringApplication.run(SpringLearnApplication.class, args);
		Test t = new Test();
		t.displayDate();
		Country c = new Country();
		c.displayCountry();
		c.displayCountries();
	}
	
	

}
