package com.cognizant.springlearn.service.exception;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

@ControllerAdvice
public class DemoException {
	
	@ResponseBody
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason = "Country Not found")
	@ExceptionHandler(value= {Exception.class})
	public ErrorMapper handleError(Exception e, HttpServletRequest req, HttpServletResponse v) {
		return new ErrorMapper(LocalDateTime.now(), 404,"Not Found",e.getMessage(),req.getRequestURI().toString());
	}
}
