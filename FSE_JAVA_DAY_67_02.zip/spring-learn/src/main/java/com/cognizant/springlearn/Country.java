package com.cognizant.springlearn;
import java.util.ArrayList;

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class Country {
	private static final Logger LOGGER = LoggerFactory.getLogger(SpringLearnApplication.class);
	String code;
	String name;
	public Country() {
		super();
		LOGGER.debug("Inside Country Constructor.");
	}
	public String getCode() {
		LOGGER.debug("getting the code");
		return code;
	}
	public void setCode(String code) {
		LOGGER.debug("setting the code");
		this.code = code;
	}
	public String getName() {
		LOGGER.debug("getting the name");
		return name;
	}
	public void setName(String name) {
		LOGGER.debug("setting the name");
		this.name = name;
	}
	@Override
	public String toString() {
		return "Country [code=" + code + ", name=" + name + "]";
	}
	
	public void displayCountry(){
		LOGGER.debug("start display country");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		Country country = (Country) context.getBean("in", Country.class);
		Country anotherCountry = context.getBean("in", Country.class);
		LOGGER.debug("Country : {}", country.toString());
		LOGGER.debug("end display country");
	}
	
	public void displayCountries() {
		LOGGER.debug("start display list of countries");
		ApplicationContext context = new ClassPathXmlApplicationContext("country.xml");
		ArrayList list = context.getBean("countryList",java.util.ArrayList.class);
		LOGGER.debug("Country : {}", list.toString());
		LOGGER.debug("end display list of countries");
	}
	
	
}
